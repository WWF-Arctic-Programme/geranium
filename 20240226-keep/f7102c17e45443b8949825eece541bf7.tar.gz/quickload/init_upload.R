rdstoken <- file.path("./dropbox-token.rds")
stopifnot(file.exists(rdstoken))
require(rdrop2)
db <- drop_auth(rdstoken=rdstoken)
print(db)
ret <- sapply(c("comments.json","config.json")[2],\(fname) {
   if (F)
      drop_delete(fname)
   db <- drop_upload(fname,verbose=F)
   print(db)
   0L
})
